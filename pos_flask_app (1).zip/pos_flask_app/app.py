from flask import Flask, render_template, request, redirect, session, send_file
import sqlite3, os
from datetime import datetime
from fpdf import FPDF

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DB = 'pos.db'

def init_db():
    with sqlite3.connect(DB) as con:
        con.execute('''CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            barcode TEXT UNIQUE NOT NULL)''')
        con.execute('''CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            qty INTEGER,
            total REAL,
            time TEXT)''')

@app.before_first_request
def setup():
    init_db()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin':
            session['user'] = 'admin'
            return redirect('/dashboard')
        else:
            return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user' not in session:
        return redirect('/')
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        barcode = request.form['barcode']
        with sqlite3.connect(DB) as con:
            con.execute("INSERT INTO products (name, price, barcode) VALUES (?, ?, ?)", (name, price, barcode))
    with sqlite3.connect(DB) as con:
        products = con.execute("SELECT * FROM products").fetchall()
    return render_template('dashboard.html', products=products)

@app.route('/add_to_cart/<int:pid>')
def add_to_cart(pid):
    with sqlite3.connect(DB) as con:
        product = con.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    if not product:
        return redirect('/dashboard')
    if 'cart' not in session:
        session['cart'] = []
    cart = session['cart']
    for item in cart:
        if item['id'] == pid:
            item['qty'] += 1
            break
    else:
        cart.append({'id': pid, 'name': product[1], 'price': product[2], 'qty': 1})
    session['cart'] = cart
    return redirect('/dashboard')

@app.route('/cart')
def cart():
    return render_template('cart.html', cart=session.get('cart', []))

@app.route('/checkout')
def checkout():
    cart = session.get('cart', [])
    if not cart:
        return redirect('/dashboard')
    with sqlite3.connect(DB) as con:
        for item in cart:
            con.execute("INSERT INTO sales (name, qty, total, time) VALUES (?, ?, ?, ?)",
                        (item['name'], item['qty'], item['qty'] * item['price'], datetime.now().isoformat()))
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Receipt", ln=True, align="C")
    total = 0
    for item in cart:
        subtotal = item['qty'] * item['price']
        total += subtotal
        pdf.cell(200, 10, txt=f"{item['name']} x {item['qty']} = {subtotal}", ln=True)
    pdf.cell(200, 10, txt=f"Total: {total}", ln=True)
    receipt_path = f"receipts/receipt_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
    pdf.output(receipt_path)
    session.pop('cart', None)
    return send_file(receipt_path, as_attachment=True)

@app.route('/report')
def report():
    with sqlite3.connect(DB) as con:
        sales = con.execute("SELECT * FROM sales").fetchall()
    return render_template('report.html', sales=sales)

if __name__ == '__main__':
    app.run(debug=True)
